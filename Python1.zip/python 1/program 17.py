#program 17
a=float(input("enter side of square:"))
b=a*a
c=4*a
print("area of square is",b)
print("perimeter of square is",c)