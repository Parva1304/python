#program 19
a = float(input("Enter radius of circle: "))
b = 22 / 7 * a * a
print("Area of circle is", b)