#program 21
a= float(input("Enter the gross salary: "))
b = a * 0.10
c = a * 0.03
d = a + b - c
print("Net Salary is:", d)