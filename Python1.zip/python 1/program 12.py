#program 12
a=float(input("enter kg"))
b=a*1000
print("convert in grams",b)
