#program 6
a=float(input("enter houe"))
b=a*60
print("convert in minuts",b )
