#program 7
a=float(input("enter minuts"))
b=a/60
print("convert in hour",b )
