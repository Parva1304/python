#program 15
a=float(input("enter faherenheit"))
b=5/9*(a-32)
print("celciusis",b)