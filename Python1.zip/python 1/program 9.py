#program 9
a=float(input("enter rs"))
b=a/48
print("convert in dollar",b )
