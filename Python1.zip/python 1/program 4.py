#program 4
a=float(input("enter the first number"))
b=float(input("enter the second number"))
c=a/b
print(c)
